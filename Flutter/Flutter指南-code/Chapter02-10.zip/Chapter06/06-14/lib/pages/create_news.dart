import 'package:flutter/material.dart';			// 引入material包

class CreateNewsPage extends StatelessWidget {	// 创建页面

  @override
  Widget build(BuildContext context) {			// 覆盖build方法
    return Center(child: Text('创建资讯'),);		// 返回居中文字
  }
}
