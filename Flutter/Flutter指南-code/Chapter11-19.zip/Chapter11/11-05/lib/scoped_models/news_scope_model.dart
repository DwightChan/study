import 'package:scoped_model/scoped_model.dart';
import '../models/news_model.dart';

class NewsScopeModel extends Model {
  List<NewsModel> _news = [];

  int _selectedIndex;

  void selectNews(int index){
    _selectedIndex = index;
  }
  int get selectedIndex{
    return _selectedIndex;
  }
  NewsModel get selectedNews{
    if(_selectedIndex == null){
      return null;
    }
    return _news[_selectedIndex];
  }

  List<NewsModel> get newsList{
    return List.from(_news);
  }
  void addNews(NewsModel news) {
    _news.add(news);
    _selectedIndex = null;
  }

  void deleteNews() {
    _news.removeAt(_selectedIndex);
    _selectedIndex = null;
  }

  void updateNews(NewsModel news) {
    _news[_selectedIndex] = news;
    _selectedIndex = null;
  }
}
