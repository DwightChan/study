import 'package:flutter/material.dart';

class NewsModel {
  final String title;
  final String description;
  final double score;
  final String image;

  NewsModel(
      {@required this.title,
      @required this.description,
      @required this.score,
      @required this.image});
}
