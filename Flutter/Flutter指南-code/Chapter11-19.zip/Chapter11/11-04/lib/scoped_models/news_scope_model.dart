import 'package:scoped_model/scoped_model.dart';
import '../models/news_model.dart';

class NewsScopeModel extends Model {
  List<NewsModel> _news = [];

  List<NewsModel> get newsList{
    return List.from(_news);
  }
  void addNews(NewsModel news) {
    _news.add(news);
  }

  void deleteNews(int index) {
    _news.removeAt(index);
  }

  void updateNews(int index, NewsModel news) {
    _news[index] = news;
  }
}
