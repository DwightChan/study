import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import '../scoped_models/news_scope_model.dart';

class NewsDetailPage extends StatelessWidget {
  final int index;

  NewsDetailPage({this.index});
  @override
  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: () {
      Navigator.pop(context, false);
      return Future.value(false);
    }, child: ScopedModelDescendant<NewsScopeModel>(
      builder: (BuildContext context, Widget child, NewsScopeModel model) {
        print('资讯详情页面 --> ScopedModelDescendant');
        return Scaffold(
          appBar: AppBar(
            title: Text(model.newsList[index].title),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Image.asset(model.newsList[index].image),
              Container(
                padding: EdgeInsets.all(10),
                child: Text('资讯详情页'),
              ),
              RaisedButton(
                color: Theme.of(context).accentColor,
                child: Text('返回'),
                onPressed: () {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('确定吗'),
                          content: Text('删除后不可以撤销！'),
                          actions: <Widget>[
                            FlatButton(
                              child: Text('删除'),
                              onPressed: () {
                                Navigator.pop(context);
                                Navigator.pop(context, true);
                              },
                            ),
                            FlatButton(
                              child: Text('取消˝'),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                            )
                          ],
                        );
                      });
                },
              )
            ],
          ),
        );
      },
    ));
  }
}
