import 'package:flutter/material.dart';

class NewsModel {
  final String title;
  final String description;
  final double score;
  final String image;
  final bool isFavorite;

  NewsModel(
      {@required this.title,
      @required this.description,
      @required this.score,
      @required this.image,
      this.isFavorite = false});
}
