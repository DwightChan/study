import 'package:flutter_news/models/user_model.dart';
import 'package:scoped_model/scoped_model.dart';

class UserScopeModel extends Model {
  UserModel _user;

  void login(String userName, String password) {
    _user = UserModel(id: '1', userName: userName, password: password);
  }
}
