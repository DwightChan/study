import 'package:scoped_model/scoped_model.dart';

import './news_scope_model.dart';
import './user_scope_model.dart';

class MainScopeModel extends Model with NewsScopeModel,UserScopeModel {

}