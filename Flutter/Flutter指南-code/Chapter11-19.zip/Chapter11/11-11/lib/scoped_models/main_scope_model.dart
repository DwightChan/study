import 'package:flutter_news/scoped_models/mix_model.dart' as prefix0;
import 'package:scoped_model/scoped_model.dart';

import './mix_model.dart';


class MainScopeModel extends Model with NewsScopeModel,UserScopeModel,MixModel {

}