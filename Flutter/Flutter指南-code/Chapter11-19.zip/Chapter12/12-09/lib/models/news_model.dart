import 'package:flutter/material.dart';

class NewsModel {
  final String id;
  final String title;
  final String description;
  final double score;
  final String image;
  final bool isFavorite;
  final String userName;
  final String userId;

  NewsModel(
      {@required this.id,
        @required this.title,
      @required this.description,
      @required this.score,
      @required this.image,
      @required this.userName,
      @required this.userId,
      this.isFavorite = false});
}
