import 'package:flutter/material.dart';
import 'package:flutter_news/scoped_models/main_scope_model.dart';
import 'package:scoped_model/scoped_model.dart';
import './score.dart';
import '../ui_element/title_defaut.dart';
import '../../models/news_model.dart';

class NewsCard extends StatelessWidget {
  final NewsModel news;
  final int index;
  NewsCard(this.news, this.index);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: <Widget>[
          FadeInImage(
            placeholder: AssetImage('assets/news1.jpg'),
            image: NetworkImage(news.image),
            height: 300,
            fit: BoxFit.cover,
          ),

          // SizedBox(
          //   height: 10.0,
          // ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              TitleDefault(news.title),
              SizedBox(
                width: 10,
              ),
              Score(news.score.toString()),
              Text(news.userName),
            ],
          ),
          ScopedModelDescendant<MainScopeModel>(
            builder:
                (BuildContext context, Widget child, MainScopeModel model) {
              return ButtonBar(
                alignment: MainAxisAlignment.center,
                children: <Widget>[
                  IconButton(
                    icon: Icon(
                      Icons.info,
                      size: 20,
                      color: Colors.red,
                    ),
                    onPressed: () => Navigator.pushNamed<bool>(
                            context, '/news/' + model.newsList[index].id)
                        .then((value) {}),
                  ),
                  IconButton(
                    icon: Icon(
                      model.newsList[index].isFavorite
                          ? Icons.favorite
                          : Icons.favorite_border,
                      size: 20,
                      color: Colors.red,
                    ),
                    onPressed: () {
                      model.selectNews(model.newsList[index].id);
                      model.toggleFavorite();
                    },
                  )
                ],
              );
            },
          )
        ],
      ),
    );
  }
}
