import 'package:scoped_model/scoped_model.dart';

import '../models/news_model.dart';
import '../models/user_model.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MixModel extends Model {
  List<NewsModel> _news = [];
  String _selectedNewsId;
  bool _showFavorites = false;
  UserModel _user;
  bool _isLoading = false;
}

class NewsScopeModel extends MixModel {
  bool get isLoading {
    return _isLoading;
  }

  void toggleDisplayModel() {
    _showFavorites = !_showFavorites;
    notifyListeners();
  }

  bool get displayFavorite {
    return _showFavorites;
  }

  Future<Null> fetchNews() {
    _isLoading = true;
    notifyListeners();
    return http
        .get('http://localhost:6379/news-api/allNewsList')
        .then((http.Response response) {
      List<dynamic> newsListData = json.decode(response.body);
      final List<NewsModel> getNewslist = [];
      newsListData.forEach((dynamic newsDataParam) {
        Map<String, dynamic> newsData = newsDataParam['productDTO'];
        NewsModel newsModel = NewsModel(
          id: newsData['id'].toString(),
          title: newsData['title'],
          description: newsData['description'],
          score: newsData['score'] == null ? 0.0 : newsData['score'],
          userId: newsData['userId'],
          userName: newsData['userEmail'],
          image: newsData['image'],
        );

        getNewslist.add(newsModel);
      });
      _news = getNewslist;
      _isLoading = false;
      notifyListeners();
    });
  }

  void fetchNewsBackend() {
    http
        .get('http://localhost:6379/news-api/allNewsList')
        .then((http.Response response) {
      List<dynamic> newsListData = json.decode(response.body);
      final List<NewsModel> getNewslist = [];
      newsListData.forEach((dynamic newsDataParam) {
        Map<String, dynamic> newsData = newsDataParam['productDTO'];
        NewsModel newsModel = NewsModel(
          id: newsData['id'].toString(),
          title: newsData['title'],
          description: newsData['description'],
          score: newsData['score'] == null ? 0.0 : newsData['score'],
          userId: newsData['userId'],
          userName: newsData['userEmail'],
          image: newsData['image'],
        );

        getNewslist.add(newsModel);
      });
      _news = getNewslist;
    });
  }

  List<NewsModel> get displayNews {
    if (_showFavorites) {
      return List.from(_news.where((NewsModel news) {
        return news.isFavorite;
      }).toList());
    } else {
      return List.from(_news);
    }
  }

  void selectNews(String newsId) {
    _selectedNewsId = newsId;
  }

  void resetSelectedNews(){
     _selectedNewsId = null;
  }

  String get selectedNewsId {
    return _selectedNewsId;
  }

  NewsModel get selectedNews {
    if (_selectedNewsId == null) {
      return null;
    }
    return _news.firstWhere((NewsModel news) {
      return news.id == _selectedNewsId;
    });
  }

  void toggleFavorite() {
    final bool currentNewsFavorite = selectedNews.isFavorite;
    final bool newValue = !currentNewsFavorite;
    final NewsModel updateNews = NewsModel(
        id: selectedNews.id,
        title: selectedNews.title,
        description: selectedNews.description,
        score: selectedNews.score,
        image: selectedNews.image,
        isFavorite: newValue,
        userId: _user.id,
        userName: _user.userName);
    final int selectedIndex = _news.indexWhere(((NewsModel news) {
      return news.id == _selectedNewsId;
    }));
    _news[selectedIndex] = updateNews;
    _selectedNewsId = null;
    notifyListeners();
  }

  List<NewsModel> get newsList {
    return List.from(_news);
  }

  Future<Null> addNews(
    String title,
    String description,
    double score,
    String image,
  ) {
    Map<String, dynamic> newsData = {
      'title': title,
      'description': description,
      'score': score.toString(),
      'userEmail': _user.userName,
      'userId': _user.id,
      'imageUrl': 'http://i9.hexunimg.cn/2014-12-04/171106102.jpg',
      'imagePath': ''
    };

    _isLoading = true;
    notifyListeners();
    return http
        .post('http://localhost:6379/news-api/addNews', body: newsData)
        .then((http.Response response) {
      Map<String, dynamic> responseData = json.decode(response.body);
      _isLoading = false;
      notifyListeners();
      // NewsModel news = NewsModel(
      //     id: responseData['id'].toString(),
      //     title: title,
      //     description: description,
      //     score: score,
      //     image: 'http://i9.hexunimg.cn/2014-12-04/171106102.jpg',
      //     userId: _user.id,
      //     userName: _user.userName);
      // _news.add(news);
      // _selectedIndex = null;
    });
  }

  void deleteNews() {
    http
        .post('http://localhost:6379/news-api/deleteNews/${selectedNews.id}')
        .then((http.Response response) {
      _selectedNewsId = null;
      fetchNewsBackend();
    });
  }

  Future<Null> updateNews(
    String title,
    String description,
    double score,
    String image,
  ) {
    _isLoading = true;
    notifyListeners();
    Map<String, dynamic> updateData = {
      'newsId': selectedNews.id,
      'title': title,
      'description': description,
      'score': score.toString(),
      'userEmail': _user.userName,
      'userId': _user.id,
      'imageUrl': 'http://i9.hexunimg.cn/2014-12-04/171106102.jpg',
      'imagePath': ''
    };
    return http
        .post('http://localhost:6379/news-api/updateNews/${selectedNews.id}',
            body: updateData)
        .then((http.Response response) {
      _isLoading = false;
      notifyListeners();
      _selectedNewsId = null;
    });
  }
}

class UserScopeModel extends MixModel {
  void login(String userName, String password) {
    _user = UserModel(id: '1', userName: userName, password: password);
  }
}
