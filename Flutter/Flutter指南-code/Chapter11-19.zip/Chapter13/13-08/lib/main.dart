import 'package:flutter/material.dart';
import 'package:flutter_news/pages/auth.dart';
import 'package:flutter_news/pages/manage_news.dart';
import 'package:flutter_news/pages/news_list.dart';
import 'package:flutter/rendering.dart';
import 'package:scoped_model/scoped_model.dart';


import './pages/news_detail.dart';
import './models/news_model.dart';
import './scoped_models/main_scope_model.dart';

void main() {
  runApp(Myapp());
  // debugPaintSizeEnabled = true;
  // debugPaintBaselinesEnabled = true;
  // debugPaintPointersEnabled = true;
}

class Myapp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyappState();
  }
}

class _MyappState extends State<Myapp> {
  MainScopeModel model = MainScopeModel();
  @override
  void initState() { 
    super.initState();
    
  }
  @override
  Widget build(BuildContext context) {
    return ScopedModel<MainScopeModel>(
      model: model,
      child: MaterialApp(
        theme: ThemeData(
          primaryColor: Colors.deepOrange,
          accentColor: Colors.deepOrange,
          brightness: Brightness.light,
        ),
        routes: {
          '/admin': (context) {
            return ManageNews(model);
          },
          '/home': (context) {
            return NewsListPage(model);
          },
          '/': (context) {
            return AuthPage();
          }
        },
        onGenerateRoute: (RouteSettings settings) {
          final List<String> paths = settings.name.split('/');
          if (paths[0] != '') {
            return null;
          }
          if (paths[1] == 'news') {
            final String newsId = paths[2];
            model.selectNews(newsId);
            return MaterialPageRoute<bool>(builder: (context) {
              return NewsDetailPage();
            });
          }
          return null;
        },
        onUnknownRoute: (RouteSettings settings) {
          return MaterialPageRoute(builder: (context) {
            return NewsListPage(model);
          });
        },
        // home: AuthPage(),
      ),
    );
  }
}
