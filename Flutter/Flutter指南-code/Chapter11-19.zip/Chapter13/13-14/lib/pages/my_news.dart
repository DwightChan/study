import 'package:flutter/material.dart';
import 'package:flutter_news/pages/edit_news.dart';
import 'package:flutter_news/scoped_models/mix_model.dart';
import 'package:scoped_model/scoped_model.dart';
import '../models/news_model.dart';
import '../scoped_models/main_scope_model.dart';

class MyNewsPage extends StatefulWidget {
  final NewsScopeModel model;
  MyNewsPage(this.model);
  @override
  State<StatefulWidget> createState() {
    return _MyNewsPageState();
  }
}

class _MyNewsPageState extends State<MyNewsPage> {
  @override
  void initState() {
    super.initState();
    widget.model.fetchNews();
  }

  Widget _buildEditButton(
      BuildContext context, int index, MainScopeModel model) {
    return IconButton(
      icon: Icon(Icons.edit),
      onPressed: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (BuildContext context) {
            model.selectNews(model.newsList[index].id);
            return EditNewsPage();
          }),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<MainScopeModel>(
      builder: (BuildContext context, Widget child, MainScopeModel model) {
        print('my');
        return Scaffold(
          body: ListView.builder(
            itemBuilder: (BuildContext context, int index) {
              Key key = Key(model.newsList[index].id);
              return Dismissible(
                onDismissed: (DismissDirection direction) {
                  if (direction == DismissDirection.endToStart) {
                    model.selectNews(model.newsList[index].id);
                    model.deleteNews();
                  }
                },
                background: Container(color: Colors.red),
                key: key,
                child: Column(
                  children: <Widget>[
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage:
                            NetworkImage(model.newsList[index].image),
                      ),
                      title: Text(model.newsList[index].title),
                      subtitle: Text('${model.newsList[index].score}'),
                      trailing: _buildEditButton(context, index, model),
                    ),
                    Divider()
                  ],
                ),
              );
            },
            itemCount: model.newsList.length,
          ),
        );
      },
    );
  }
}
