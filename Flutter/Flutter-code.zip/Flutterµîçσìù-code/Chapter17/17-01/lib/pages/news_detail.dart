import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import '../scoped_models/main_scope_model.dart';
import 'dart:math' as math;

class NewsDetailPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _NewsDetailPageState();
  }
}

class _NewsDetailPageState extends State<NewsDetailPage>
    with TickerProviderStateMixin {
  AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<MainScopeModel>(
      builder: (BuildContext context, Widget child, MainScopeModel model) {
        return WillPopScope(
          onWillPop: () {
            model.resetSelectedNews();
            Navigator.pop(context, false);
            return Future.value(false);
          },
          child: Scaffold(
            body: CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(
                  pinned: true,
                  expandedHeight: 300,
                  flexibleSpace: FlexibleSpaceBar(
                    title: Text(model.selectedNews.title),
                    background: Hero(
                      tag: model.selectedNews.id,
                      child: FadeInImage(
                        placeholder: AssetImage('assets/news1.jpg'),
                        image: NetworkImage(model.selectedNews.image),
                        height: 300,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                SliverList(
                  delegate: SliverChildListDelegate([
                    Container(
                      padding: EdgeInsets.all(10),
                      child: Text(model.selectedNews.description),
                    ),
                  ]),
                )
              ],
            ),
            floatingActionButton: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ScaleTransition(
                  scale: CurvedAnimation(
                      parent: _controller,
                      curve: Interval(0, 1, curve: Curves.easeOut)),
                  child: FloatingActionButton(
                    backgroundColor: Colors.white,
                    heroTag: 'like',
                    mini: true,
                    child: Icon(
                      model.selectedNews.isFavorite
                          ? Icons.favorite
                          : Icons.favorite_border,
                      color: Theme.of(context).accentColor,
                    ),
                    onPressed: () {
                      model.toggleFavorite();
                    },
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                ScaleTransition(
                  scale: CurvedAnimation(
                      parent: _controller,
                      curve: Interval(0, 1, curve: Curves.easeOut)),
                  child: FloatingActionButton(
                    backgroundColor: Colors.white,
                    mini: true,
                    heroTag: 'email',
                    child: Icon(
                      Icons.email,
                      color: Theme.of(context).accentColor,
                    ),
                    onPressed: () {},
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                FloatingActionButton(
                  heroTag: 'option',
                  child: AnimatedBuilder(
                      animation: _controller,
                      builder: (BuildContext context, Widget child) {
                        return Transform(
                            alignment: FractionalOffset.center,
                            transform: Matrix4.rotationZ(
                                _controller.value * 0.5 * math.pi),
                            child: Icon(Icons.more_vert));
                      }),
                  onPressed: () {
                    if (_controller.isDismissed) {
                      _controller.forward();
                    } else {
                      _controller.reverse();
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
