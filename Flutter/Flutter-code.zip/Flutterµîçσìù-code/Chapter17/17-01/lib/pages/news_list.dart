import 'package:flutter/material.dart';
import 'package:flutter_news/scoped_models/mix_model.dart';
import 'package:flutter_news/widgets/ui_element/logout.dart';
import 'package:scoped_model/scoped_model.dart';
import '../widgets/news/news.dart';

import '../models/news_model.dart';
import '../scoped_models/main_scope_model.dart';

class NewsListPage extends StatefulWidget {
  final NewsScopeModel model;
  NewsListPage(this.model);
  @override
  State<StatefulWidget> createState() {
    return _NewsListPageState();
  }
}

class _NewsListPageState extends State<NewsListPage> {
  @override
  void initState() {
    super.initState();
    widget.model.fetchNews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Column(
          children: <Widget>[
            AppBar(
              automaticallyImplyLeading: false,
              title: Text('选择'),
            ),
            ListTile(
              leading: Icon(Icons.list),
              title: Text('管理资讯'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/admin');
              },
            ),
            Logout()
          ],
        ),
      ),
      appBar: AppBar(
        actions: <Widget>[
          ScopedModelDescendant<MainScopeModel>(builder:
              (BuildContext context, Widget child, MainScopeModel model) {
            return IconButton(
              icon: model.displayFavorite
                  ? Icon(Icons.favorite)
                  : Icon(Icons.favorite_border),
              onPressed: () {
                model.toggleDisplayModel();
              },
            );
          }),
        ],
        title: Text('资讯列表'),
      ),
      body: ScopedModelDescendant<MainScopeModel>(
          builder: (BuildContext context, Widget child, MainScopeModel model) {
            print('list');
        return model.isLoading
            ? Center(child: CircularProgressIndicator())
            : RefreshIndicator(child: News(),onRefresh: (){
              return model.fetchNews();
            },);
      }),
    );
  }
}
