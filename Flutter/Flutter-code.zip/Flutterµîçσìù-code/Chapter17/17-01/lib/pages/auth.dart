import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import './news_list.dart';
import '../scoped_models/main_scope_model.dart';

enum AuthMode { Singup, Login }

class AuthPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _AuthPageState();
  }
}

class _AuthPageState extends State<AuthPage> with TickerProviderStateMixin {
  AnimationController _controller;
  Animation<Offset> _slideAnimation;
  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    _slideAnimation = Tween(begin: Offset(0, -2), end: Offset(0, 0)).animate(
        CurvedAnimation(
            parent: _controller,
            curve: Interval(0, 1, curve: Curves.fastOutSlowIn)));
  }

  final TextEditingController _passwordController = TextEditingController();
  String _username;
  String _password;
  bool _accept = false;
  AuthMode _authMode = AuthMode.Login;
  GlobalKey<FormState> _form = GlobalKey<FormState>();
  DecorationImage buildBackgroundImage() {
    return DecorationImage(
      colorFilter:
          ColorFilter.mode(Colors.black.withOpacity(0.5), BlendMode.dstATop),
      fit: BoxFit.cover,
      image: AssetImage('assets/bg.jpg'),
    );
  }

  TextFormField buildUsernameTextField() {
    return TextFormField(
      keyboardType: TextInputType.emailAddress,
      decoration: InputDecoration(
          labelText: '用户名', filled: true, fillColor: Colors.white),
      onSaved: (value) {
        _username = value;
      },
    );
  }

  TextFormField buildPasswordTextField() {
    return TextFormField(
      controller: _passwordController,
      obscureText: true,
      decoration: InputDecoration(
          labelText: '密码', filled: true, fillColor: Colors.white),
      onSaved: (value) {
        _password = value;
      },
    );
  }

  FadeTransition buildConfirmTextField() {
    return FadeTransition(
      opacity: CurvedAnimation(
          parent: _controller, curve: Interval(0, 1, curve: Curves.easeIn)),
      child: SlideTransition(
        position: _slideAnimation,
        child: TextFormField(
          validator: (String value) {
            if (value != _passwordController.text) {
              return '两次密码输入不一致';
            }
            return null;
          },
          obscureText: true,
          decoration: InputDecoration(
              labelText: '确认', filled: true, fillColor: Colors.white),
        ),
      ),
    );
  }

  SwitchListTile buildAccept() {
    return SwitchListTile(
      title: Text('接受条款'),
      value: _accept,
      onChanged: (bool value) {
        setState(() {
          _accept = value;
        });
      },
    );
  }

  void submit(MainScopeModel model) async {
    if (!_form.currentState.validate()) {
      return;
    }
    _form.currentState.save();

    Map<String, dynamic> response;
    if (_authMode == AuthMode.Login) {
      response = await model.login(_username, _password);
    } else {
      response = await model.signup(_username, _password);
    }
    if (response['success']) {
      Navigator.pushReplacementNamed(context, '/home');
    } else {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('提示信息'),
              content: Text(response['message']),
              actions: <Widget>[
                RaisedButton(
                  child: Text('确认'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                )
              ],
            );
          });
    }
  }

  @override
  Widget build(BuildContext context) {
    final double deviceWidth = MediaQuery.of(context).size.width;
    final targetWidth = deviceWidth > 768.0 ? 500.0 : deviceWidth * 0.8;

    return Scaffold(
      appBar: AppBar(
        title: Text('登录'),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          image: buildBackgroundImage(),
        ),
        child: Form(
          key: _form,
          child: Container(
            alignment: Alignment.center,
            child: SingleChildScrollView(
              child: Container(
                width: targetWidth,
                child: Column(
                  children: <Widget>[
                    buildUsernameTextField(),
                    SizedBox(
                      height: 10,
                    ),
                    buildPasswordTextField(),
                    SizedBox(
                      height: 10,
                    ),
                    _authMode == AuthMode.Login
                        ? Container()
                        : buildConfirmTextField(),
                    buildAccept(),
                    FlatButton(
                      child: Text(
                          '切换到${_authMode == AuthMode.Login ? '注册' : '登录'}'),
                      onPressed: () {
                        setState(() {
                          if (_authMode == AuthMode.Login) {
                            _authMode = AuthMode.Singup;
                            _controller.forward();
                          } else {
                            _authMode = AuthMode.Login;
                            _controller.reverse();
                          }
                        });
                      },
                    ),
                    ScopedModelDescendant<MainScopeModel>(builder:
                        (BuildContext context, Widget child,
                            MainScopeModel model) {
                      print('auth');
                      return model.isLoading
                          ? CircularProgressIndicator()
                          : RaisedButton(
                              textColor: Colors.white,
                              color: Theme.of(context).accentColor,
                              child: Text(
                                  '${_authMode == AuthMode.Login ? '登录' : '注册'}'),
                              onPressed: () {
                                submit(model);
                              },
                            );
                    }),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
