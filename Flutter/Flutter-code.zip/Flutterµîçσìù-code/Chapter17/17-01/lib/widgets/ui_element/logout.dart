import 'package:flutter/material.dart';
import 'package:flutter_news/scoped_models/main_scope_model.dart';
import 'package:scoped_model/scoped_model.dart';

class Logout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<MainScopeModel>(
      builder: (BuildContext context, Widget child, MainScopeModel model) {
        return ListTile(
          title: Text('退出'),
          onTap: () {
            model.logout();
            Navigator.pushReplacementNamed(context, '/');
          },
        );
      },
    );
  }
}
