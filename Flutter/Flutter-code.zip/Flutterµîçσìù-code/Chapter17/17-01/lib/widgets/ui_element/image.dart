import 'dart:io';
import 'package:scoped_model/scoped_model.dart';
import '../../scoped_models/main_scope_model.dart';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ImageInput extends StatefulWidget {
  final Function setImage;
  final Function initImage;
  ImageInput(this.setImage,this.initImage);
  _ImageInputState createState() => _ImageInputState();
}

class _ImageInputState extends State<ImageInput> {
  File _imageFile;

  Widget _buildImagePreView(MainScopeModel model) {
    if (_imageFile != null) {
      return Image.file(
        _imageFile,
        fit: BoxFit.cover,
        height: 300,
      );
    } else if (model.selectedNewsId != null) {
      widget.initImage(model.selectedNews.image);
      return Image.network(
        model.selectedNews.image,
        fit: BoxFit.cover,
        height: 300,
      );
    } else {
      return Center(
        child: Text('请选择图片'),
      );
    }
  }

  void openImagePicker(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return ScopedModelDescendant<MainScopeModel>(builder:
              (BuildContext context, Widget child, MainScopeModel model) {
            return Container(
              height: 150,
              padding: EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  FlatButton(
                    child: Text('相机'),
                    onPressed: () {
                      ImagePicker.pickImage(
                              source: ImageSource.camera, maxWidth: 400)
                          .then((File imageFile) {
                        setState(() {
                          _imageFile = imageFile;
                        });
                        Navigator.of(context).pop();
                      });
                    },
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  FlatButton(
                    child: Text('图库'),
                    onPressed: () {
                      ImagePicker.pickImage(
                              source: ImageSource.gallery, maxWidth: 400)
                          .then((File imageFile) {
                        setState(() {
                          widget.setImage(imageFile, model);
                          _imageFile = imageFile;
                        });
                        Navigator.of(context).pop();
                      });
                    },
                  )
                ],
              ),
            );
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<MainScopeModel>(
      builder: (BuildContext context, Widget child, MainScopeModel model) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            OutlineButton(
              borderSide: BorderSide(
                  color: Theme.of(context).accentColor,
                  width: 2,
                  style: BorderStyle.solid),
              child: Text('选择图片'),
              onPressed: () {
                openImagePicker(context);
              },
            ),
            SizedBox(
              height: 10,
            ),
            _buildImagePreView(model)
          ],
        );
      },
    );
  }
}
