import 'package:flutter/material.dart';
main(){

}

class Myapp extends StatelessWidget{
  build(context) {
    return MaterialApp();
  }
}