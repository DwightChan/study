import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_news/pages/auth.dart';
import 'package:flutter_news/pages/manage_news.dart';
import 'package:flutter_news/pages/news_list.dart';
import 'package:flutter/rendering.dart';
import 'package:scoped_model/scoped_model.dart';

import './pages/news_detail.dart';
import './models/news_model.dart';
import './scoped_models/main_scope_model.dart';
import './widgets/custom_route.dart';

void main() {
  runApp(Myapp());
  // debugPaintSizeEnabled = true;
  // debugPaintBaselinesEnabled = true;
  // debugPaintPointersEnabled = true;
}

class Myapp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyappState();
  }
}

class _MyappState extends State<Myapp> {
  MethodChannel _channel = MethodChannel(
    'x7data.com/battery',
  );
  Future<Null> getBatteryLevel() async {
    String batteryLevel;
    try {
      final int result = await _channel.invokeMethod('getBatteryLevel');
      batteryLevel = '电池状态$result';
    } catch (error) {
      batteryLevel = '获取电池状态失败';
    }
    print(batteryLevel);
  }

  MainScopeModel _model = MainScopeModel();
  bool _isAuth = false;
  @override
  void initState() {
    super.initState();
    getBatteryLevel();
    _model.autoAuthenticate();
    _model.userSubject.listen((dynamic isAuth) {
      setState(() {
        _isAuth = isAuth;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModel<MainScopeModel>(
      model: _model,
      child: MaterialApp(
        theme: Theme.of(context).platform == TargetPlatform.iOS
            ? ThemeData(
                primaryColor: Colors.deepPurple,
                accentColor: Colors.deepPurpleAccent,
                brightness: Brightness.dark,
              )
            : ThemeData(
                primaryColor: Colors.deepOrange,
                accentColor: Colors.deepOrange,
                brightness: Brightness.light,
              ),
        routes: {
          '/admin': (context) {
            return !_isAuth ? AuthPage() : ManageNews(_model);
          },
          '/home': (context) {
            return !_isAuth ? AuthPage() : NewsListPage(_model);
          },
          '/': (context) {
            return !_isAuth ? AuthPage() : NewsListPage(_model);
          }
        },
        onGenerateRoute: (RouteSettings settings) {
          final List<String> paths = settings.name.split('/');
          if (paths[0] != '') {
            return null;
          }
          if (paths[1] == 'news') {
            final String newsId = paths[2];
            _model.selectNews(newsId);
            return CustomRoute<bool>(builder: (context) {
              return !_isAuth ? AuthPage() : NewsDetailPage();
            });
          }
          return null;
        },
        onUnknownRoute: (RouteSettings settings) {
          return MaterialPageRoute(builder: (context) {
            return !_isAuth ? AuthPage() : NewsListPage(_model);
          });
        },
        // home: AuthPage(),
      ),
    );
  }
}
