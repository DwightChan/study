import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import '../../pages/news_detail.dart';
import './score.dart';
import './news_card.dart';

import '../../models/news_model.dart';
import '../../scoped_models/news_scope_model.dart';

class News extends StatelessWidget {
  Widget buildNewsList(List<NewsModel> news) {
    Widget newsCard;
    if (news.length > 0) {
      newsCard = ListView.builder(
        itemBuilder: (BuildContext context, int index) {
          return NewsCard(news[index], index);
        },
        itemCount: news.length,
      );
    } else {
      newsCard = Center(child: Text('没有找到news'));
      // newsCard = Container();
    }
    return newsCard;
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<NewsScopeModel>(
      builder: (BuildContext context, Widget child, NewsScopeModel model) {
        return buildNewsList(model.newsList);
      },
    );
  }
}
