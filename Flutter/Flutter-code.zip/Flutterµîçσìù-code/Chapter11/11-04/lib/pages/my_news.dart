import 'package:flutter/material.dart';
import 'package:flutter_news/pages/edit_news.dart';
import 'package:scoped_model/scoped_model.dart';
import '../models/news_model.dart';
import '../scoped_models/news_scope_model.dart';

class MyNewsPage extends StatelessWidget {
  Widget _buildEditButton(BuildContext context, int index,NewsScopeModel model) {
    return IconButton(
      icon: Icon(Icons.edit),
      onPressed: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (BuildContext context) {
            return EditNewsPage(news:model.newsList[index],index: index,);
          }),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<NewsScopeModel>(
      builder: (BuildContext context, Widget child, NewsScopeModel model) {
        print('我的资讯页面 --> ScopedModelDescendant');
        return Scaffold(
          body: ListView.builder(
            itemBuilder: (BuildContext context, int index) {
              Key key = Key(model.newsList[index].title);
              return Dismissible(
                onDismissed: (DismissDirection direction) {
                  if (direction == DismissDirection.endToStart) {
                    model.deleteNews(index);
                  }
                },
                background: Container(color: Colors.red),
                key: key,
                child: Column(
                  children: <Widget>[
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage:
                            AssetImage(model.newsList[index].image),
                      ),
                      title: Text(model.newsList[index].title),
                      subtitle: Text('${model.newsList[index].score}'),
                      trailing: _buildEditButton(context, index, model),
                    ),
                    Divider()
                  ],
                ),
              );
            },
            itemCount: model.newsList.length,
          ),
        );
      },
    );
  }
}
