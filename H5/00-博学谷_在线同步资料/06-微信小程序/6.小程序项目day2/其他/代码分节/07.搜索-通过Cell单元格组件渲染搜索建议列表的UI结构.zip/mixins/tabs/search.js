import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 搜索框中的默认内容
    value: '',
    // 搜索建议列表
    suggestList: []
  }

  methods = {
    // 当搜索关键字发生变化，会触发这个时间处理函数
    onChange(e) {
      if (e.detail.trim().length <= 0) {
        this.suggestList = []
        return
      }
      this.getSuggestList(e.detail)
    },

    // 触发了搜索
    onSearch(e) {
      // e.detail 就是最新的搜索关键字
      console.log(e.detail)
    },

    // 触发了取消
    onCancel(e) {
      this.suggestList = []
    }
  }

  async getSuggestList(searchStr) {
    const { data: res } = await wepy.get('/goods/qsearch', { query: searchStr })

    if (res.meta.status !== 200) {
      return wepy.baseToast()
    }

    this.suggestList = res.message
    this.$apply()
    console.log(this.suggestList)
  }
}
