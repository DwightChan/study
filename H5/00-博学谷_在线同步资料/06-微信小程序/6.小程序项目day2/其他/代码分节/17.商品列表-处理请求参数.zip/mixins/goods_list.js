import wepy from 'wepy'

export default class extends wepy.mixin {

  data = {
    // 查询关键字
    query: '',
    // 商品分类的id
    cid: '',
    // 页码值
    pagenum: 1,
    // 每页显示多少条数据
    pagesize: 10
  }

  onLoad(options) {
    console.log(options)

    this.query = options.query || ''
    this.cid = options.cid || ''
    this.getGoodsList()
  }

  // 获取商品列表数据
  getGoodsList() {}
}
