import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 搜索框中的默认内容
    value: ''
  }

  methods = {
    // 触发了搜索
    onSearch(e) {
      // e.detail 就是最新的搜索关键字
      console.log(e.detail)
    },

    // 触发了取消
    onCancel(e) {}
  }
}
