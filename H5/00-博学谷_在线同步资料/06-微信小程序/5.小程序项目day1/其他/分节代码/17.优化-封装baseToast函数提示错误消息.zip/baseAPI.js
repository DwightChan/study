import wepy from 'wepy'

/**
 * 弹框提示一个无图标的 Toast 消息
 * @str 要提示的消息内容
 */

 wepy.baseToast = function (str = '获取数据失败') {
   wepy.showToast({
     title: str,
     icon: 'none',
     duration: 2000,
   });
 }
 