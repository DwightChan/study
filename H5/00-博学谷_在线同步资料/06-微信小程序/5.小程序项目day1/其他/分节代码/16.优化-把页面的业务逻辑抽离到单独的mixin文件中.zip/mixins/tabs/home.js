import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    swiperList: [],
    cateItems: []
  }
  onLoad() {
    this.getSwiperData()
    this.getCateItems()
  }

  // 获取轮播图数据的函数
  async getSwiperData() {
    const { data: res } = await wepy.request({
      url: 'https://www.zhengzhicheng.cn/api/public/v1/home/swiperdata',
      data: {},
      method: 'GET'
    })

    if (res.meta.status !== 200) {
      // return console.log('获取数据失败')
      return wepy.showToast({
        title: '获取数据失败',
        icon: 'none',
        duration: 2000
      })
    }
    this.swiperList = res.message
    this.$apply()
  }

  // 获取输液分类选项数据
  async getCateItems() {
    const { data: res } = await wepy.request({
      url: 'https://www.zhengzhicheng.cn/api/public/v1/home/catitems',
      method: 'get',
      data: {}
    })

    if (res.meta.status !== 200) {
      // return console.log('获取数据失败')
      return wepy.showToast({
        title: '获取数据失败',
        icon: 'none',
        duration: 2000
      })
    }

    this.cateItems = res.message
    console.log(this.cateItems)
    this.$apply()
  }
}
