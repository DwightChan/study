import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 购物车商品列表
    cart: []
  }

  onLoad() {
    this.cart = this.$parent.globalData.cart
  }

  methods = {
    // 获取商品数量变化的事件
    countChanged(e) {
      // 获取商品商品更新之后最新的值
      console.log(e.detail)

      // 通过自定义的方式获取商品的 id
      console.log(e.target.dataset.id)
    }
  }

  computed = {
    // 判断购物车是否为空
    isEmpty() {
      if (this.cart.length <= 0) {
        return true
      }

      return false
    }
  }
}