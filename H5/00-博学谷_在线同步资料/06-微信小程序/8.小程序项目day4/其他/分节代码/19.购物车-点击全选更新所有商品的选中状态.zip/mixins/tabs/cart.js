import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 购物车商品列表
    cart: []
  }

  onLoad() {
    this.cart = this.$parent.globalData.cart
  }

  methods = {
    // 获取商品数量变化的事件
    countChanged(e) {
      // 获取商品商品更新之后最新的值
      // console.log(e.detail)
      const count = e.detail
      // 通过自定义的方式获取商品的 id
      // console.log(e.target.dataset.id)
      const id = e.target.dataset.id
      this.$parent.updateGoodsCount(id, count)
    },

    // 当商品前面的复选框，选中状态发生变化，会触发这个函数
    statusChanged(e) {

      // 当前最新的选中状态
      const status = e.detail
      // 当前单机项对应的商品 id
      const id = e.target.dataset.id

      console.log(status)

      this.$parent.updateGoodsStatus(id, status)
    },

    // 点击删除对应的商品
    close(id) {
      this.$parent.removeFoodsById(id)
    },

    // 监听全选复选框值改变的事件
    onFullCheckChange(e) {
      this.$parent.updateAllGoodsStatus(e.detail)
    }
  }

  computed = {
    // 判断购物车是否为空
    isEmpty() {
      if (this.cart.length <= 0) {
        return true
      }

      return false
    },

    // 总价格，单位是 分
    amount() {
      let total = 0
      this.cart.forEach(x => {
        if (x.isCheck) {
          total += x.price * x.count
        }
      })

      return total * 100
    },

    isFullChecked() {
      // 获取所有商品的个数
      const allCount = this.cart.length

      let c = 0
      this.cart.forEach(x => {
        if (x.isCheck) {
          c++
        }
      })

      return allCount === c
    }
  }
}