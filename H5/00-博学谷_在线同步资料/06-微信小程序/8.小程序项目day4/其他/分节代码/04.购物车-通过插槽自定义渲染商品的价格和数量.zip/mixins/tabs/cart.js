import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 购物车商品列表
    cart: []
  }

  onLoad() {
    this.cart = this.$parent.globalData.cart
  }

  methods = {}

  computed = {
    // 判断购物车是否为空
    isEmpty() {
      if (this.cart.length <= 0) {
        return true
      }

      return false
    }
  }
}