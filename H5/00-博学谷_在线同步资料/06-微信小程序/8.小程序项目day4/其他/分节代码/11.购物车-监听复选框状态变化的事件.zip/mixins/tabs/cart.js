import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 购物车商品列表
    cart: []
  }

  onLoad() {
    this.cart = this.$parent.globalData.cart
  }

  methods = {
    // 获取商品数量变化的事件
    countChanged(e) {
      // 获取商品商品更新之后最新的值
      // console.log(e.detail)
      const count = e.detail
      // 通过自定义的方式获取商品的 id
      // console.log(e.target.dataset.id)
      const id = e.target.dataset.id
      this.$parent.updateGoodsCount(id, count)
    },

    // 当商品前面的复选框，选中状态发生变化，会触发这个函数
    statusChanged(e) {
      console.log(e)

      // 当前最新的选中状态
      const status = e.detail
      // 当前单机项对应的商品 id
      const id = e.target.dataset.id

      console.log(status)
    }
  }

  computed = {
    // 判断购物车是否为空
    isEmpty() {
      if (this.cart.length <= 0) {
        return true
      }

      return false
    }
  }
}