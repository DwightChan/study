"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RED = '#f44';
exports.BLUE = '#1989fa';
exports.GREEN = '#07c160';
