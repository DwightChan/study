import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    addressInfo: null,
    cart: [],
    // 是否登录成功了
    islogin: false
  }

  onLoad() {
    // 读取收货地址
    this.addressInfo = wepy.getStorageSync('address') || null
    // 从购物车列表中，将那些被勾选的的商品，过滤出来，形成一个新的数组
    const newArr = this.$parent.globalData.cart.filter(x => x.isCheck)

    this.cart = newArr
  }

  methods = {
    async chooseAddress() {
      // 选择收货地址
      const res = await wepy.chooseAddress().catch(err => err)
      // console.log(res)

      if (res.errMsg !== 'chooseAddress:ok') {
        return
      }

      this.addressInfo = res
      wepy.setStorageSync('address', res)
      this.$apply()
      console.log(this.addressInfo)
    },

    // 获取用户的信息
    async getUserInfo(userInfo) {
      // 判断是否获取用户信息失败
      if (userInfo.detail.errMsg !== 'getUserInfo:ok') {
        return wepy.baseToast('获取用户信息失败！')
      }

      console.log(userInfo)

      // 获取用户登录的凭证 Code
      const loginRes = await wepy.login()
      console.log(loginRes)
      if (loginRes.errMsg !== 'login:ok') {
        return wepy.baseToast('微信登录失败！')
      }

      // 登录的参数
      const loginParams = {
        code: loginRes.code,
        encryptedData: userInfo.detail.encryptedData,
        iv: userInfo.detail.iv,
        rawData: userInfo.detail.rawData,
        signature: userInfo.detail.signature
      }

    }
  }

  computed = {
    isHaveAddress() {
      if (this.addressInfo === null) {
        return false
      }
      return true
    },

    addressStr() {
      if (this.addressInfo === null) {
        return ''
      }

      return this.addressInfo.provinceName + this.addressInfo.cityName + this.addressInfo.countyName + this.addressInfo.detailInfo
    }
  }
}
