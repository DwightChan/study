import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    // 搜索框中的默认内容
    value: '',
    // 搜索建议列表
    suggestList: [],
    // 搜索历史列表
    kwList: []
  }

  onLoad() {
    const kwList = wx.getStorageSync('kw') || []
    this.kwList = kwList
    console.log(this.kwList)
  }

  computed = {
    // true  展示搜索历史区域
    // false 展示搜索建议区域
    isShowHistory() {
      if (this.value.length <= 0) {
        return true
      }

      return false
    }
  }

  methods = {
    // 当搜索关键字发生变化，会触发这个时间处理函数
    onChange(e) {
      if (e.detail.trim().length <= 0) {
        this.suggestList = []
        return
      }
      this.value = e.detail.trim()
      this.getSuggestList(e.detail)
    },

    // 触发了搜索
    onSearch(e) {
      let kw = e.detail.trim()
      // e.detail 就是最新的搜索关键字
      if (kw.length <=0) {
        return
      }

      // 把用户填写的搜索关键字，保存到 Storage  中
      if (this.kwList.indexOf(kw) === -1) {
        this.kwList.unshift(kw)
      }

      // 数组的 slice 方法，不会修改原数组，而是返回一个新的数组
      this.kwList = this.kwList.splice(0, 10)
      wepy.setStorageSync('kw', this.kwList);

      wepy.navigateTo({
        url: '/pages/goods_list?query=' + kw
      })
    },

    // 触发了取消
    onCancel(e) {
      this.suggestList = []
    },

    // 点击搜索建议项，导航到商品详情页
    goGoodsDetail(goods_id) {
      wepy.navigateTo({
        url: '/pages/goods_detail/main?goods_id=' + goods_id
      })
    },

    // 点击每个 Tag 标签，导航到商品列表页面，同事把参数传递过去
    goGoodsList(query) {
      wepy.navigateTo({
        url: '/pages/goods_list?query=' + query
      })
    },

    // 清除搜索历史按钮
    clearHistory() {
      this.kwList = []
      wepy.setStorageSync('kw', [])
    }
  }

  async getSuggestList(searchStr) {
    const { data: res } = await wepy.get('/goods/qsearch', { query: searchStr })

    if (res.meta.status !== 200) {
      return wepy.baseToast()
    }

    this.suggestList = res.message
    this.$apply()
    console.log(this.suggestList)
  }
}
