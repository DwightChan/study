import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    addressInfo: null,
    cart: []
  }

  onLoad() {
    // 读取收货地址
    this.addressInfo = wepy.getStorageSync('address') || null

    const newArr = this.$parent.globalData.cart.filter(x => x.isCheck)

    this.cart = newArr
  }

  methods = {
    async chooseAddress() {
      // 选择收货地址
      const res = await wepy.chooseAddress().catch(err => err)
      // console.log(res)

      if (res.errMsg !== 'chooseAddress:ok') {
        return
      }

      this.addressInfo = res
      wepy.setStorageSync('address', res)
      this.$apply()
      console.log(this.addressInfo)
    }
  }

  computed = {
    isHaveAddress() {
      if (this.addressInfo === null) {
        return false
      }
      return true
    },

    addressStr() {
      if (this.addressInfo === null) {
        return ''
      }

      return this.addressInfo.provinceName + this.addressInfo.cityName + this.addressInfo.countyName + this.addressInfo.detailInfo
    }
  }
}
