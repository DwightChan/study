import wepy from 'wepy'

export default class extends wepy.mixin {}