import wepy from 'wepy'

export default class extends wepy.mixin {
  data = {
    addressInfo: null
  }

  methods = {
    async chooseAddress() {
      // 选择收货地址
      const res = await wepy.chooseAddress().catch(err => err)
      // console.log(res)

      if (res.errMsg !== 'chooseAddress:ok') {
        return
      }

      this.addressInfo = res
      wepy.setStorageSync('address', res)
      this.$apply()
      console.log(this.addressInfo)
    }
  }
}
