# vuex-shopcart
> 购物车demo

# 安装依赖
npm install

# 启动server
npm run dev

# 编译发布
npm run build
```
