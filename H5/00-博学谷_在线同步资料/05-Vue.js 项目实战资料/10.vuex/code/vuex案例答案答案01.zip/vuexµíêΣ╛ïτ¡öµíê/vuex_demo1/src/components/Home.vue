<template>
  <div class="hello">
    <h1>{{ city }}</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },
  computed: {
    city: function() {
      // 通过vuex的getters方法来获取state里面的数据
      return this.$store.getters.getCityFn
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
