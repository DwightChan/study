<template>
    <div class="city">
        <ul>
            <li
                v-for="(item, index) in cityArr"
                :key="index"
                @click="backFn(index)"
            >
                <h2>{{ item }}</h2>
            </li>
        </ul>
    </div>
</template>
<script>
export default {
  name: 'HelloWorld',
  data() {
    return {
      cityArr: [
        '北京',
        '上海',
        '广州',
        '深圳',
        '成都',
        '西安',
        '太原',
        '杭州',
        '沈阳',
        '天津'
      ]
    }
  },
  methods: {
    backFn: function(index) {
      // 调用vuex的ations设置城市的值
      this.$store.dispatch('setCityName', this.cityArr[index])

      //返回到首页
      this.$router.push('/')
    }
  }
}
</script>
