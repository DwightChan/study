<template>
  <div id="app">
    首页
    <Home />
    <CityList />
  </div>
</template>

<script>
import Home from './components/Home.vue'
import CityList from './components/CityList.vue'

export default {
  name: 'app',
  components: {
    Home,
    CityList
  }
}
</script>

<style></style>
